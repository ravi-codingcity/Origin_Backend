const express = require("express");
const dotenv = require("dotenv");
const connectDB = require("./config/db");
const authRoutes = require("./routes/auth");
const formRoutes = require("./routes/OriginformRoutes");
const railFreightRoutes = require("./routes/RailFreightRoutes");
const itAssetRoutes = require("./routes/itAssets/itAssetRoutes");
const itAuthRoutes = require("./routes/itAssets/itAuthRoutes");
const itHealthRoutes = require("./routes/itAssets/itHealthRoutes");
const visitorRoutes = require("./routes/visitorRoutes");
const jobPortalRoutes = require("./routes/jobPortal/jobPortalRoutes");
const isfFilingRoutes = require("./routes/ISF_filing/isfFilingRoutes");
const userManagementRoutes = require("./routes/userManagementRoutes");
const healthRoutes = require("./routes/healthRoutes");
const bodyParser = require("body-parser");
const cookieParser = require("cookie-parser");
const session = require("express-session");
const helmet = require("helmet");
const cors = require("cors");
const errorHandler = require("./middleware/errorHandler");

dotenv.config(); // Load environment variables from .env file

const app = express();

// Connect to database
connectDB()
  .then(() => {
    console.log("MongoDB connected successfully");
  })
  .catch((error) => {
    console.error("MongoDB connection failed:", error.message);
  });

// Middleware
app.use(helmet());
// CORS: restrict to configured origin(s) when CORS_ORIGIN is set
// (comma-separated list); otherwise fall back to open CORS for the
// other existing modules.
const corsOrigins = process.env.CORS_ORIGIN
  ? process.env.CORS_ORIGIN.split(",").map((o) => o.trim())
  : null;
app.use(cors(corsOrigins ? { origin: corsOrigins, credentials: true } : {}));
app.use(bodyParser.json());
app.use(cookieParser());
app.use(
  session({
    secret: process.env.JWT_SECRET, // Use secret key from environment variable
    resave: false,
    saveUninitialized: true,
  })
);

// Health check
app.use("/health", healthRoutes);

// Routes
app.use("/api/origin/auth", authRoutes);// Ensure this route is correctly set up
app.use("/api/origin/forms", formRoutes);
app.use("/api/railfreight/forms", railFreightRoutes);

// IT Assets Routes
app.use("/api/v1/itAssets/health", itHealthRoutes);
app.use("/api/v1/itAssets/auth", itAuthRoutes);
app.use("/api/v1/itAssets/assets", itAssetRoutes);

// Visitor Counter
app.use("/api/visitor", visitorRoutes);

// Job Portal (HR + public Careers)
app.use("/api/job-portal", jobPortalRoutes);

// ISF Filing
app.use("/api/isf-filing", isfFilingRoutes);

// User Management — IT Admin only. Reached from the IT Assets portal;
// authentication happens at /api/v1/itAssets/auth/login.
// There is no registration endpoint anywhere in this API.
app.use("/api/admin", userManagementRoutes);


// Error Handling Middleware
app.use(errorHandler);

// Start server
const PORT = process.env.PORT || 3000;
const server = app.listen(PORT)
  .on('listening', () => {
    console.log(`Server running on port ${PORT}`);
  })
  .on('error', (err) => {
    if (err.code === 'EADDRINUSE') {
      console.error(`Port ${PORT} is already in use. Please:
      1. Stop any other servers running on this port, OR
      2. Choose a different port by changing the PORT environment variable`);
      process.exit(1);
    } else {
      console.error('Server error:', err);
    }
  });
